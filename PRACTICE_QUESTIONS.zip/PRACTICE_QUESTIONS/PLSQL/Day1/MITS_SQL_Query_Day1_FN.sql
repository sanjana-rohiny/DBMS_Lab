create database MITS;
use MITS;

CREATE TABLE Event (
    eventid INT PRIMARY KEY,
    name VARCHAR(255) UNIQUE NOT NULL,
    description TEXT,
    city VARCHAR(100) NOT NULL
);

CREATE TABLE Participant (
    playerid VARCHAR(255) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    eventid INT CHECK (gender IN ('M', 'F')),
    gender CHAR(1),
    year INT,
    FOREIGN KEY (eventid) REFERENCES Event(eventid)
);

CREATE TABLE Prizes (
    prizeid INT PRIMARY KEY,
    prize_money DECIMAL(7, 2) CHECK (prize_money BETWEEN 500.00 AND 1500.00),
    eventid INT,
    rank1 INT CHECK (rank1 IN (1, 2, 3)),
    year INT,
    FOREIGN KEY (eventid) REFERENCES Event(eventid)
);

CREATE TABLE Winners (
    prizeid INT,
    playerid VARCHAR(255),
    PRIMARY KEY (prizeid, playerid),
    FOREIGN KEY (prizeid) REFERENCES Prizes(prizeid),
    FOREIGN KEY (playerid) REFERENCES Participant(playerid)
);

INSERT INTO Event (eventid, name, description, city)
VALUES
    (1, 'Music Festival', 'A weekend of live music and entertainment.', 'Los Angeles'),
    (2, 'Tech Conference', 'Bringing together tech enthusiasts and experts.', 'San Francisco'),
    (3, 'Art Exhibition', 'Showcasing local and international artists.', 'New York'),
    (4, 'Food Festival', 'Celebrating diverse culinary delights.', 'Chicago'),
    (5, 'Sports Tournament', 'Competitive sports action in various disciplines.', 'Dallas'),
    (6, 'Charity Gala', 'Raising funds for a noble cause.', 'Boston'),
    (7, 'Fashion Show', 'Displaying the latest fashion trends.', 'Miami'),
    (8, 'Film Screening', 'Showcasing new and classic films.', 'Los Angeles'),
    (9, 'Science Symposium', 'Exploring cutting-edge scientific discoveries.', 'San Francisco'),
    (10, 'Cultural Fair', 'Highlighting cultural heritage through exhibits and performances.', 'New York');


INSERT INTO Participant (playerid, name, eventid, gender, year)
VALUES
    ('P001', 'Alice', 1, 'F', 2000),
    ('P002', 'Bob', 1, 'M', 1998),
    ('P003', 'Charlie', 2, 'M', 1995),
    ('P004', 'David', 3, 'M', 2002),
    ('P005', 'Eva', 4, 'F', 1999),
    ('P006', 'Frank', 5, 'M', 1997),
    ('P007', 'Grace', 6, 'F', 2001),
    ('P008', 'Henry', 7, 'M', 1994),
    ('P009', 'Ivy', 8, 'F', 1996),
    ('P010', 'Jack', 9, 'M', 2003);

INSERT INTO Prizes (prizeid, prize_money, eventid, rank1, year)
VALUES
    (1, 1000.00, 1, 1, 2023),
    (2, 750.00, 1, 2, 2023),
    (3, 500.00, 1, 3, 2023),
    (4, 1200.00, 2, 1, 2023),
    (5, 800.00, 2, 2, 2023),
    (6, 600.00, 2, 3, 2023),
    (7, 1500.00, 3, 1, 2023),
    (8, 1000.00, 3, 2, 2023),
    (9, 750.00, 3, 3, 2023),
    (10, 1000.00, 4, 1, 2023);
    
INSERT INTO Winners (prizeid, playerid)
VALUES
    (1, 'P001'),
    (4, 'P001'),
    (8, 'P001'),
    (2, 'P002'),
    (5, 'P002'),
    (9, 'P002'),
    (3, 'P003'),
    (10, 'P003'),
    (6, 'P004'),
    (7, 'P005');

#1 Retrieve the names of the persons who have won the highest number of 1st, 2nd and 3rd prizes.
select max(P.name) 
from Participant P, Winners W,  Prizes PR 
where P.playerid = W.playerid and W.prizeid = PR.prizeid and PR.rank1 = 1 or PR.rank1 = 2 or PR.rank1 = 3  
group by P.playerid, P.name limit 3;
 
#2 Retrieve the name of events where all prize winners are females.
select distinct  E.name 
from Winners W, Participant P, Event E 
where W.playerid = P.playerid and E.eventid = P.eventid and P.gender= 'F';

#3 Retrieve the name of the person who has won the highest amount of prize
select W.playerid, P.name, sum(PR.prize_money) 
from  Winners W, Prizes PR, Participant P 
where PR.prizeid = W.prizeid and P.playerid = W.playerid 
group by W.playerid order by sum(PR.prize_money) DESC limit 1;

#4 Retrieve the name of the events which do not have 3 prize winners.
select E.name from Event E LEFT JOIN  (
                select PR.eventid, count(PR.rank1) as count_winner 
                from Prizes PR, Winners W 
                where PR.prizeid = W.prizeid group by PR.eventid)  J1
                on J1.eventid = E.eventid where  count_winner is NULL or count_winner <> 3;
            
#5 Retrieve the name of all 2nd prize winners along with the event name.
select P.name, E.name 
from Participant P, Event E, Winners W, Prizes PR 
where  P.eventid = E.eventid and 
W.playerid = P.playerid and 
PR.prizeid = W.prizeid  and 
PR.rank1 = 2;

